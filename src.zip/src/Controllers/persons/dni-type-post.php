<?php

return [
    [
        'code' =>'CC',
        'text' => 'cédula de ciudadania'
    ],
    [
        'code' =>'TI',
        'text' => 'tarjeta de identidad'
    ]
];