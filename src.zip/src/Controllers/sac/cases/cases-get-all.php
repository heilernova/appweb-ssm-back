<?php

use App\Models\CasesModel;

$mode = new CasesModel();

return $mode->getAll();